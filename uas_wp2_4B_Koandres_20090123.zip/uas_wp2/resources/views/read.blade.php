<table class="table">

    <thead>
        <tr>

            <th scope="col">#</th>
            <th scope="col">Kategori</th>
            <th scope="col">Nama Barang</th>
            <th scope="col">Jumlah</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($tbldata as $tbldata)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $tbldata->kategori }}</td>
            <td>{{ $tbldata->nama }}</td>
            <td>{{ $tbldata->jumlah }}</td>
            <td>
                <button class="badge rounded-pill text-bg-warning" onclick="show({{ $tbldata->id }})">Update</button>
                <button class="badge rounded-pill text-bg-danger" onclick="destroy({{ $tbldata->id }})">Delete</button>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>