<?php

use App\Http\Controllers\barangController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [barangController::class, 'index']);
Route::get('/read', [barangController::class, 'read']);
Route::get('/create', [barangController::class, 'create']);
Route::get('/store', [barangController::class, 'store']);
Route::get('/show/{id}', [barangController::class, 'show']);
Route::get('/update/{id}', [barangController::class, 'update']);
Route::get('/destroy/{id}', [barangController::class, 'destroy']);
