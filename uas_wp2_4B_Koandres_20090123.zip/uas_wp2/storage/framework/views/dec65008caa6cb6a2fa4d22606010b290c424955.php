<table class="table">

    <thead>
        <tr>

            <th scope="col">#</th>
            <th scope="col">Kategori</th>
            <th scope="col">Nama Barang</th>
            <th scope="col">Jumlah</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tbldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($tbldata->kategori); ?></td>
            <td><?php echo e($tbldata->nama); ?></td>
            <td><?php echo e($tbldata->jumlah); ?></td>
            <td>
                <button class="badge rounded-pill text-bg-warning" onclick="show(<?php echo e($tbldata->id); ?>)">Update</button>
                <button class="badge rounded-pill text-bg-danger" onclick="destroy(<?php echo e($tbldata->id); ?>)">Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\uas_wp2\resources\views/read.blade.php ENDPATH**/ ?>