<div class="p2">
    <div class="form-group mb-3">
        <input type="text" name="kategori" id="kategori" class="form-control " placeholder="Kategori Barang..." required autocomplete="off">
    </div>
    <div class="form-group mb-3">
        <input type="text" name="nama" id="nama" class="form-control " placeholder="Nama Barang..." required autocomplete="off">
    </div>
    <div class="form-group mb-3">
        <input type="text" name="jumlah" id="jumlah" class="form-control " placeholder="Jumlah Barang..." required autocomplete="off">
    </div>
    <div class="form-group mt-5">
        <button class="btn btn-dark" onclick="store()">Tambah Data</button>
    </div>
</div><?php /**PATH D:\uas_wp2\resources\views/create.blade.php ENDPATH**/ ?>